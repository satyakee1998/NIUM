package com.dashboard.bean;




public class NIUMCreateUserBean {
	
	String dzip;
	public String getDzip() {
		return dzip;
	}
	public void setDzip(String dzip) {
		this.dzip = dzip;
	}
	private String nationality;
	public String getNationality() {
		return nationality;
	}
	public void setNationality(String nationality) {
		this.nationality = nationality;
	}
	private String first_name;
	private String middle_name;
//	private String preferredame;
	private String last_name;
	private String gender;
	private String bday;
	private String phone_number;
	
	private String country;

	private String country_isd_code;
	
	private String address_line_1;
	private String address_line_2;
	private String city;
	private String state;
	private String emall;
	public String getEmall() {
		return emall;
	}
	public void setEmall(String emall) {
		this.emall = emall;
	}
	private String post_code;
	
	private String billing_country;
	private String billing_address_line_1;
	private String billing_address_line_2;
	private String billing_city;
	private String billing_state;
	private String billing_post_code;
	private String preferred_currency;
	
	private String username;
	
	private String email;
	
	private String password;
	
	String client_agent_subAgent_name;
	String agent_code;
	String sub_agent_code;
	
	String io_bb;
	String myccode;
	String billingzip;
	
	
//	public String getPreferredame() {
//		return preferredame;
//	}
//	public void setPreferredame(String preferredame) {
//		this.preferredame = preferredame;
//	}
	
	public String getBillingzip() {
		return billingzip;
	}
	public void setBillingzip(String billingzip) {
		this.billingzip = billingzip;
	}
	public String getIo_bb() {
		return io_bb;
	}
	public void setIo_bb(String io_bb) {
		this.io_bb = io_bb;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	
	
	
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}

	
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getAddress_line_1() {
		return address_line_1;
	}
	public void setAddress_line_1(String address_line_1) {
		this.address_line_1 = address_line_1;
	}
	public String getAddress_line_2() {
		return address_line_2;
	}
	public void setAddress_line_2(String address_line_2) {
		this.address_line_2 = address_line_2;
	}
	public String getBilling_country() {
		return billing_country;
	}
	public void setBilling_country(String billing_country) {
		this.billing_country = billing_country;
	}
	public String getBilling_address_line_1() {
		return billing_address_line_1;
	}
	public void setBilling_address_line_1(String billing_address_line_1) {
		this.billing_address_line_1 = billing_address_line_1;
	}
	public String getBilling_address_line_2() {
		return billing_address_line_2;
	}
	public void setBilling_address_line_2(String billing_address_line_2) {
		this.billing_address_line_2 = billing_address_line_2;
	}
	public String getBilling_city() {
		return billing_city;
	}
	public void setBilling_city(String billing_city) {
		this.billing_city = billing_city;
	}
	public String getBilling_state() {
		return billing_state;
	}
	public void setBilling_state(String billing_state) {
		this.billing_state = billing_state;
	}
	public String getBilling_post_code() {
		return billing_post_code;
	}
	public void setBilling_post_code(String billing_post_code) {
		this.billing_post_code = billing_post_code;
	}
	public String getPreferred_currency() {
		return preferred_currency;
	}
	public void setPreferred_currency(String preferred_currency) {
		this.preferred_currency = preferred_currency;
	}
	public String getPhone_number() {
		return phone_number;
	}
	public void setPhone_number(String phone_number) {
		this.phone_number = phone_number;
	}
	public String getFirst_name() {
		return first_name;
	}
	public void setFirst_name(String first_name) {
		this.first_name = first_name;
	}
	public String getMiddle_name() {
		return middle_name;
	}
	public void setMiddle_name(String middle_name) {
		this.middle_name = middle_name;
	}
	public String getLast_name() {
		return last_name;
	}
	public void setLast_name(String last_name) {
		this.last_name = last_name;
	}
	public String getCountry_isd_code() {
		return country_isd_code;
	}
	public void setCountry_isd_code(String country_isd_code) {
		this.country_isd_code = country_isd_code;
	}
	public String getBday() {
		return bday;
	}
	public void setBday(String bday) {
		this.bday = bday;
	}
	public String getPost_code() {
		return post_code;
	}
	public void setPost_code(String post_code) {
		this.post_code = post_code;
	}
	public String getClient_agent_subAgent_name() {
		return client_agent_subAgent_name;
	}
	public void setClient_agent_subAgent_name(String client_agent_subAgent_name) {
		this.client_agent_subAgent_name = client_agent_subAgent_name;
	}
	public String getAgent_code() {
		return agent_code;
	}
	public void setAgent_code(String agent_code) {
		this.agent_code = agent_code;
	}
	public String getSub_agent_code() {
		return sub_agent_code;
	}
	public void setSub_agent_code(String sub_agent_code) {
		this.sub_agent_code = sub_agent_code;
	}
	public String getMyccode() {
		return myccode;
	}
	public void setMyccode(String myccode) {
		this.myccode = myccode;
	}
}
