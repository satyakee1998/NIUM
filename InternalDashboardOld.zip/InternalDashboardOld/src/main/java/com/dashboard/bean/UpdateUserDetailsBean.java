package com.dashboard.bean;

public class UpdateUserDetailsBean {

String id;
String first_name;
String last_name;
String middle_name;
String mobileCountryCode;
String mobile;
String title;
String gender;
String id_type;
String id_number;
String country_of_issue;
String birthDate;

public String getFirst_name() {
return first_name;
}
public void setFirst_name(String first_name) {
this.first_name = first_name;
}
public String getLast_name() {
return last_name;
}
public void setLast_name(String last_name) {
this.last_name = last_name;
}
public String getMiddle_name() {
return middle_name;
}
public void setMiddle_name(String middle_name) {
this.middle_name = middle_name;
}
public String getMobileCountryCode() {
return mobileCountryCode;
}
public void setMobileCountryCode(String mobileCountryCode) {
this.mobileCountryCode = mobileCountryCode;
}
public String getMobile() {
return mobile;
}
public void setMobile(String mobile) {
this.mobile = mobile;
}
public String getId() {
return id;
}
public void setId(String id) {
this.id = id;
}
public String getTitle() {
return title;
}
public void setTitle(String title) {
this.title = title;
}
public String getGender() {
return gender;
}
public void setGender(String gender) {
this.gender = gender;
}
public String getId_type() {
return id_type;
}
public void setId_type(String id_type) {
this.id_type = id_type;
}
public String getId_number() {
return id_number;
}
public void setId_number(String id_number) {
this.id_number = id_number;
}
public String getCountry_of_issue() {
return country_of_issue;
}
public void setCountry_of_issue(String country_of_issue) {
this.country_of_issue = country_of_issue;
}
public String getBirthDate() {
return birthDate;
}
public void setBirthDate(String birthDate) {
this.birthDate = birthDate;
}





}