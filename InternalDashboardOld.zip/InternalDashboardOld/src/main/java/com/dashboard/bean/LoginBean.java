package com.dashboard.bean;

public class LoginBean {
private String email;
private String password;
private String fname;
private String agentcode;
public String getEmail() {
return email;
}
public void setEmail(String email) {
this.email = email;
}
public String getPassword() {
return password;
}
public void setPassword(String password) {
this.password = password;
}
public String getFname() {
return fname;
}
public void setFname(String fname) {
this.fname = fname;
}
public String getAgentcode() {
return agentcode;
}
public void setAgentcode(String agentcode) {
this.agentcode = agentcode;
}
public String getSubagentcode() {
return subagentcode;
}
public void setSubagentcode(String subagentcode) {
this.subagentcode = subagentcode;
}
private String subagentcode;

}