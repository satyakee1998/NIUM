package com.dashboard.bean;

import java.util.List;

public class UploadDocumentsBean {
	
	List<IdentificationDocBean> identificationDoc;

	public List<IdentificationDocBean> getIdentificationDoc() {
		return identificationDoc;
	}

	public void setIdentificationDoc(List<IdentificationDocBean> identificationDoc) {
		this.identificationDoc = identificationDoc;
	}

}
