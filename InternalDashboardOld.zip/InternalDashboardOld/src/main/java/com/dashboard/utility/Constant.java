package com.dashboard.utility;

public interface Constant {
	String STARTING = "1";
	String ENDING = "1000";
	String Agent_Code ="Agent_Code";
	String Sub_Agent_Code="Sub_Agent_code";
	String client_agent_subAgent_name="StylopayTest";
	String Email = "mithilesh@stylopay.com";
	String Password = "W@llet123";
	String OauthUrl = System.getenv("OathUrl");
	String MMUrl=System.getenv("MMUrl");
	String NIUMUrl="http://developer.sandbox.stylopay.com:8081/NISG";
	String xApiKey = "tDwjoMFPiL1XDYTjb8H313BWbmFlh1ve21usj7Oj";
	String clientHasId = "cebd2dfb-b010-48ef-b2f2-ac7e640e3a68";
	String nisgEmail="testadminnisg01@yopmail.com";
	String nisgPassword = "W@llet123";
	String customererid="af793050-2148-4966-a28a-9d23bab54c52";
}
